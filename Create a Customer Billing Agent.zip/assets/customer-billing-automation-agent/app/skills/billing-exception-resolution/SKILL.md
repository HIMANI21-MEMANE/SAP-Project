---
name: billing-exception-resolution
description: Step-by-step guidance for resolving billing blocks, pricing discrepancies, and data mismatches in SAP S/4HANA
---

# Billing Exception Resolution Guide

Use this skill when the user needs guidance on resolving a specific billing block, pricing error, or data mismatch.

## Step 1: Identify the Block Reason Code

Retrieve the billing document details to find the block reason code. Common reason codes and their meanings:

| Block Code | Description | Root Cause |
|------------|-------------|------------|
| 01 | Pricing Incomplete | One or more pricing conditions are missing or could not be determined |
| 02 | Credit Limit Exceeded | Customer's credit exposure exceeds the credit limit |
| 03 | Delivery Not Goods-Issued | Goods issue has not been posted for the outbound delivery |
| 04 | Incomplete Data | Mandatory fields (e.g., payment terms, tax data) are missing on the document |
| 05 | Account Assignment Incomplete | GL account or cost centre cannot be determined |
| 06 | Customer Master Incomplete | Customer master data is missing required fields for billing |
| 07 | Export/Foreign Trade Block | Export data or foreign trade data is incomplete |
| 08 | Intercompany Block | Intercompany billing configuration is missing |

## Step 2: Resolution Decision Tree

### Block Code 01 — Pricing Incomplete
1. Navigate to **VK13** (Display Condition Record) to check whether a valid price exists for the material/customer combination.
2. If missing, navigate to **VK11** (Create Condition Record) to create the missing pricing condition.
3. Once the condition record exists, navigate to **VA02** (Change Sales Order) and re-run pricing (menu: Edit → Update prices).
4. Reprocess the billing document from **VF04** (Billing Due List).

### Block Code 02 — Credit Limit Exceeded
1. Navigate to **FD32** (Change Customer Credit Data) to review the customer's current credit exposure and limit.
2. Option A: Release the billing document manually via **VKM1** (Blocked SD Documents — Credit Management).
3. Option B: Increase the credit limit in **FD32** if business-justified.
4. Contact the credit manager for approval if the release requires sign-off.

### Block Code 03 — Delivery Not Goods-Issued
1. Navigate to **VL02N** (Change Outbound Delivery) and confirm goods issue status.
2. If goods issue is pending, post it via menu: Post Goods Issue.
3. Verify the goods issue posting in **MB51** (Material Document List).
4. Return to **VF04** and reprocess the billing item.

### Block Code 04 — Incomplete Data
1. Navigate to **VA02** (Change Sales Order) or **VL02N** (Change Delivery).
2. Use menu: Edit → Incompletion Log to identify which fields are missing.
3. Fill in the missing fields and save.
4. Reprocess in **VF04**.

### Block Code 05 — Account Assignment Incomplete
1. Navigate to **OKB9** (Default Account Assignment) or check the material's account assignment group in **MM03**.
2. Verify the GL account determination in **VKOA** (Account Determination for Revenue).
3. Correct the configuration or master data, then reprocess in **VF04**.

### Block Code 06 — Customer Master Incomplete
1. Navigate to **XD02** (Change Customer — Central) or **VD02** (Change Customer — Sales) to check the customer master.
2. Review the Billing tab for missing payment terms, tax classification, or reconciliation account.
3. Complete the missing data and save.
4. Reprocess in **VF04**.

## Step 3: Pricing Discrepancy Resolution

If the billing document shows a pricing discrepancy (billed amount does not match expected):

1. Navigate to **VF03** (Display Billing Document) and go to the item pricing tab.
2. Compare the pricing conditions against the sales order (**VA03**) pricing conditions.
3. If a condition was manually changed in the sales order, it may not have transferred correctly — investigate in **VA03** → Item → Conditions.
4. If correct conditions are missing, follow Block Code 01 steps above.
5. If the discrepancy is due to a retroactive price change, check whether a credit/debit memo request is required.

## Step 4: Data Mismatch Resolution

If billing document data (partner, address, payment terms) does not match the sales order:

1. Navigate to **VA03** (Display Sales Order) and compare the partner functions and header data.
2. If the customer master was changed after order creation, update the order via **VA02**.
3. For address mismatches, navigate to **XD02** and correct the address.
4. Reprocess in **VF04**.

## Step 5: Final Verification

After resolving any block:
1. Navigate to **VF04** (Billing Due List) and filter for the resolved document.
2. Execute billing to generate the billing document.
3. Confirm the billing document is created without error in **VF03**.
4. Verify the FI posting was created in **FB03** (Display Document).
