---
name: period-end-readiness
description: Rules and checklist for confirming billing completeness before period-end financial close
---

# Period-End Billing Readiness Checklist

Use this skill when generating a period-end readiness report or assessing whether billing is complete enough for the financial close cycle to proceed.

## Readiness Criteria

All five criteria below must pass for the overall status to be **"Ready for Close"**. Any failing criterion results in **"Not Ready for Close"**.

### Criterion 1: Zero Unprocessed Billing-Due List Items
- **Pass**: No billing-due list items remain in pending or open status for the fiscal period.
- **Fail**: One or more items remain pending. Report count and document types.
- **Action if Fail**: Retrieve pending items list; prioritize by earliest open date; escalate items older than 5 business days to the Finance Controller.

### Criterion 2: No Open Billing Blocks
- **Pass**: No billing documents for the period have an active billing block reason code.
- **Fail**: One or more documents have billing blocks. Report count grouped by block reason code.
- **Action if Fail**: Load the `billing-exception-resolution` skill for each distinct block reason code and provide resolution steps.

### Criterion 3: All Released Billing Documents Posted to FI-AR
- **Pass**: Every billing document in "Released" status has a corresponding accounting document entry in accounts receivable.
- **Fail**: One or more released billing documents have no corresponding AR accounting document. Report count.
- **Action if Fail**: Flag each unposted document number as an FI posting exception. Recommend the Finance Controller check the FI posting run or contact the AR accountant.

### Criterion 4: All FI Postings Reflected in General Ledger
- **Pass**: Journal entry line items exist for every accounting document linked to the period's billing documents.
- **Fail**: One or more accounting documents have no GL journal entries. Report count.
- **Action if Fail**: Flag documents with missing GL entries. Recommend reviewing the posting run or checking for suspended journal entries.

### Criterion 5: No Pricing Discrepancy Exceptions Open
- **Pass**: No billing documents for the period have a pricing discrepancy flag (Block Code 01) or an open credit/debit memo request linked to a pricing correction.
- **Fail**: Pricing discrepancies remain unresolved. Report count.
- **Action if Fail**: Load the `billing-exception-resolution` skill for Block Code 01 guidance.

## Readiness Report Format

The readiness report must include:

```
Period-End Billing Readiness Report
=====================================
Fiscal Period: [YYYY/MM]
Report Generated: [timestamp]

OVERALL STATUS: [Ready for Close | Not Ready for Close]

Summary:
- Total billing items for period: [N]
- Items fully processed: [N]
- Items pending: [N]
- Billing blocks open: [N]
- FI posting gaps (AR): [N]
- GL journal entry gaps: [N]
- Pricing discrepancies: [N]

Criteria Results:
✅/❌ Criterion 1: Zero unprocessed billing-due list items — [PASS/FAIL]
✅/❌ Criterion 2: No open billing blocks — [PASS/FAIL]
✅/❌ Criterion 3: All released documents posted to FI-AR — [PASS/FAIL]
✅/❌ Criterion 4: All FI postings reflected in GL — [PASS/FAIL]
✅/❌ Criterion 5: No open pricing discrepancies — [PASS/FAIL]

[If Not Ready]: Action Required:
- [List specific document numbers and recommended next steps for each failing criterion]
```

## Escalation Guidance

Escalate to the Finance Controller immediately if:
- More than 10 items remain unprocessed within 1 business day of period-end close.
- FI posting gaps exist for documents older than 3 business days.
- A billing block has been open for more than 5 business days without resolution.

Escalate to the IT/SAP Basis team if:
- FI postings are consistently failing (more than 5 documents with no AR or GL entries).
- The billing-due list API is returning errors or empty results unexpectedly.
