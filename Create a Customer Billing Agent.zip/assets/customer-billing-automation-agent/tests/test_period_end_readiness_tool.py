"""Unit tests for period-end readiness report (R4)."""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "app"))


def _compute_readiness(billing_items, posted_docs, journal_entries):
    """Compute readiness report from mock data."""
    total = len(billing_items)
    pending = [i for i in billing_items if i.get("BillingBlock") not in ("", None)]
    released = [i for i in billing_items if i.get("BillingBlock") in ("", None)]

    fi_gaps = []
    for item in released:
        doc_num = item["BillingDocument"]
        acctg = posted_docs.get(doc_num)
        if not acctg:
            fi_gaps.append(doc_num)
            continue
        je = journal_entries.get(acctg.get("AccountingDocument", ""), [])
        if not je:
            fi_gaps.append(doc_num)

    is_ready = len(pending) == 0 and len(fi_gaps) == 0
    return {
        "total": total,
        "processed": len(released) - len(fi_gaps),
        "pending": len(pending),
        "fi_posting_gaps": len(fi_gaps),
        "status": "Ready for Close" if is_ready else "Not Ready for Close",
    }


BILLING_ITEMS_CLEAN = [
    {"BillingDocument": "9000000101", "BillingBlock": ""},
    {"BillingDocument": "9000000102", "BillingBlock": ""},
]

BILLING_ITEMS_WITH_BLOCKS = [
    {"BillingDocument": "9000000101", "BillingBlock": ""},
    {"BillingDocument": "9000000102", "BillingBlock": "01"},
]

POSTED_DOCS = {
    "9000000101": {"AccountingDocument": "1400000101"},
    "9000000102": {"AccountingDocument": "1400000102"},
}

JOURNAL_ENTRIES = {
    "1400000101": [{"GLAccount": "400000"}],
    "1400000102": [{"GLAccount": "400000"}],
}


def test_readiness_report_ready_when_all_processed(add_agent_to_path):
    """R4: Status is 'Ready for Close' when all items processed and FI posted."""
    report = _compute_readiness(BILLING_ITEMS_CLEAN, POSTED_DOCS, JOURNAL_ENTRIES)
    assert report["status"] == "Ready for Close"
    assert report["pending"] == 0
    assert report["fi_posting_gaps"] == 0


def test_readiness_report_not_ready_with_billing_blocks(add_agent_to_path):
    """R4: Status is 'Not Ready for Close' when billing blocks remain."""
    report = _compute_readiness(BILLING_ITEMS_WITH_BLOCKS, POSTED_DOCS, JOURNAL_ENTRIES)
    assert report["status"] == "Not Ready for Close"
    assert report["pending"] == 1


def test_readiness_report_not_ready_with_fi_posting_gaps(add_agent_to_path):
    """R4: Status is 'Not Ready for Close' when FI posting gaps exist."""
    no_postings = {}
    report = _compute_readiness(BILLING_ITEMS_CLEAN, no_postings, {})
    assert report["status"] == "Not Ready for Close"
    assert report["fi_posting_gaps"] > 0


def test_readiness_report_structure(add_agent_to_path):
    """R4: Readiness report contains all required fields."""
    report = _compute_readiness(BILLING_ITEMS_CLEAN, POSTED_DOCS, JOURNAL_ENTRIES)
    required_fields = ["total", "processed", "pending", "fi_posting_gaps", "status"]
    for field in required_fields:
        assert field in report


def test_readiness_report_totals_correct(add_agent_to_path):
    """R4: Total count matches input billing items."""
    report = _compute_readiness(BILLING_ITEMS_WITH_BLOCKS, POSTED_DOCS, JOURNAL_ENTRIES)
    assert report["total"] == 2
    assert report["pending"] == 1


def test_readiness_status_values_are_canonical(add_agent_to_path):
    """R4: Status values must be exactly 'Ready for Close' or 'Not Ready for Close'."""
    report_ready = _compute_readiness(BILLING_ITEMS_CLEAN, POSTED_DOCS, JOURNAL_ENTRIES)
    report_not_ready = _compute_readiness(BILLING_ITEMS_WITH_BLOCKS, POSTED_DOCS, JOURNAL_ENTRIES)

    assert report_ready["status"] == "Ready for Close"
    assert report_not_ready["status"] == "Not Ready for Close"
