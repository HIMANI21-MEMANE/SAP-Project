"""Unit tests for FI posting validation (R3)."""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "app"))

MOCK_ACCOUNTING_DOCS = {
    "9000000101": {
        "AccountingDocument": "1400000101",
        "CompanyCode": "1000",
        "FiscalYear": "2026",
        "ReferenceSDDocument": "9000000101",
        "AccountingDocumentType": "RV",
    },
    "9000000102": {
        "AccountingDocument": "1400000102",
        "CompanyCode": "1000",
        "FiscalYear": "2026",
        "ReferenceSDDocument": "9000000102",
        "AccountingDocumentType": "RV",
    },
}

MOCK_JOURNAL_ENTRIES = {
    "1400000101": [
        {
            "AccountingDocument": "1400000101",
            "GLAccount": "400000",
            "DebitCreditCode": "S",
            "AmountInCompanyCodeCurrency": "12500.00",
        }
    ],
    "1400000102": [
        {
            "AccountingDocument": "1400000102",
            "GLAccount": "400000",
            "DebitCreditCode": "S",
            "AmountInCompanyCodeCurrency": "8750.00",
        }
    ],
}


def test_fi_posting_validation_detects_posted_document(add_agent_to_path):
    """R3: Billing document with accounting doc is confirmed as posted."""
    billing_doc = "9000000101"
    acctg_doc = MOCK_ACCOUNTING_DOCS.get(billing_doc)

    assert acctg_doc is not None
    assert acctg_doc["AccountingDocumentType"] == "RV"
    assert acctg_doc["CompanyCode"] == "1000"


def test_fi_posting_validation_detects_unposted_document(add_agent_to_path):
    """R3: Billing document without accounting doc is flagged as FI exception."""
    billing_doc = "9000000999"  # does not exist
    acctg_doc = MOCK_ACCOUNTING_DOCS.get(billing_doc)

    assert acctg_doc is None


def test_gl_journal_entry_exists_for_posted_document(add_agent_to_path):
    """R3: Posted accounting document has corresponding GL journal entries."""
    billing_doc = "9000000101"
    acctg_doc = MOCK_ACCOUNTING_DOCS.get(billing_doc)
    assert acctg_doc is not None

    journal_entries = MOCK_JOURNAL_ENTRIES.get(acctg_doc["AccountingDocument"], [])
    assert len(journal_entries) > 0
    assert journal_entries[0]["GLAccount"] == "400000"


def test_gl_journal_entry_missing_is_partial_posting(add_agent_to_path):
    """R3: Accounting doc exists but no GL journal entry = partial posting."""
    # Simulate: accounting doc exists but no journal entry
    acctg_doc_with_no_je = "1400009999"
    journal_entries = MOCK_JOURNAL_ENTRIES.get(acctg_doc_with_no_je, [])

    assert len(journal_entries) == 0  # should be flagged as partial


def test_fi_posting_status_per_document(add_agent_to_path):
    """R3: Each billing document gets a clear AR+GL posting status."""
    billing_docs = ["9000000101", "9000000102", "9000000999"]
    statuses = []

    for doc in billing_docs:
        acctg = MOCK_ACCOUNTING_DOCS.get(doc)
        if not acctg:
            statuses.append({"doc": doc, "status": "unposted"})
            continue
        je = MOCK_JOURNAL_ENTRIES.get(acctg["AccountingDocument"], [])
        if je:
            statuses.append({"doc": doc, "status": "posted"})
        else:
            statuses.append({"doc": doc, "status": "partially_posted"})

    assert statuses[0]["status"] == "posted"
    assert statuses[1]["status"] == "posted"
    assert statuses[2]["status"] == "unposted"


def test_debit_credit_code_on_ar_entry(add_agent_to_path):
    """R3: AR posting has debit code 'S' (standard for customer invoices)."""
    for entries in MOCK_JOURNAL_ENTRIES.values():
        for entry in entries:
            assert entry["DebitCreditCode"] in ("S", "H")
