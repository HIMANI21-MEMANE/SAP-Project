"""Integration test: end-to-end agent flow for period-end readiness report."""
import json
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "app"))

# Mock billing-due list response
MOCK_BILLING_LIST_RESPONSE = json.dumps({
    "d": {
        "results": [
            {
                "BillingDocument": "9000000101",
                "BillingDocumentType": "F2",
                "BillingBlock": "",
                "CompanyCode": "1000",
                "NetAmount": "12500.00",
                "TransactionCurrency": "EUR",
            }
        ]
    }
})

# Mock accounting document response
MOCK_ACCTG_DOC_RESPONSE = json.dumps({
    "d": {
        "results": [
            {
                "AccountingDocument": "1400000101",
                "CompanyCode": "1000",
                "FiscalYear": "2026",
                "ReferenceSDDocument": "9000000101",
                "AccountingDocumentType": "RV",
                "AmountInCompanyCodeCurrency": "12500.00",
            }
        ]
    }
})

# Mock journal entry response
MOCK_JOURNAL_ENTRY_RESPONSE = json.dumps({
    "d": {
        "results": [
            {
                "AccountingDocument": "1400000101",
                "GLAccount": "400000",
                "DebitCreditCode": "S",
                "AmountInCompanyCodeCurrency": "12500.00",
            }
        ]
    }
})

# Mock LLM response for period-end readiness report
MOCK_LLM_RESPONSE = """Based on the data retrieved from SAP S/4HANA:

**Period-End Billing Readiness Report — 2026/11**
Overall Status: Ready for Close ✅

- Total billing items: 1
- Items processed: 1
- Items pending: 0
- FI posting gaps: 0

All billing documents (9000000101) have been confirmed posted to FI-AR (Accounting Document: 1400000101) and GL (Journal Entry confirmed). The period is ready for financial close."""


def _make_mock_tool(name: str, response: str):
    tool = MagicMock()
    tool.name = name
    tool.ainvoke = AsyncMock(return_value=response)
    return tool


@pytest.mark.asyncio
async def test_period_end_readiness_full_flow(add_agent_to_path):
    """Integration: Finance Controller asks for period-end readiness, agent invokes all 3 APIs and returns structured report."""
    from agent import SampleAgent

    mock_tools = [
        _make_mock_tool("lis", MOCK_BILLING_LIST_RESPONSE),
        _make_mock_tool("ge", MOCK_BILLING_LIST_RESPONSE),
        _make_mock_tool("coun", json.dumps({"d": {"__count": "1"}})),
        _make_mock_tool("list_a_journalentryitembasic_for_api_journalentryitembasic_srv", MOCK_JOURNAL_ENTRY_RESPONSE),
        _make_mock_tool("get_metadata_api_subsqnt_billg_doc_sbi_srv", json.dumps({"metadata": "<edmx/>"})),
        _make_mock_tool("get_metadata_api_oplacctgdocitemcube_srv", json.dumps({"metadata": "<edmx/>"})),
        _make_mock_tool("get_metadata_api_journalentryitembasic_srv", json.dumps({"metadata": "<edmx/>"})),
    ]

    mock_message = MagicMock()
    mock_message.content = MOCK_LLM_RESPONSE

    mock_graph_result = {"messages": [mock_message]}

    with patch("mcp_providers.agw.get_mcp_tools", AsyncMock(return_value=mock_tools)):
        with patch("langchain_litellm.ChatLiteLLM") as mock_llm_class:
            mock_llm = MagicMock()
            mock_llm_class.return_value = mock_llm

            with patch("langchain.agents.create_agent") as mock_create_agent:
                mock_graph = AsyncMock()
                mock_graph.ainvoke = AsyncMock(return_value=mock_graph_result)
                mock_create_agent.return_value = mock_graph

                agent = SampleAgent()
                response = await agent.invoke(
                    query="Generate a period-end billing readiness report for period 2026/11",
                    context_id="test-context-001",
                    tools=mock_tools,
                )

    assert response.status == "completed"
    assert response.message is not None
    assert len(response.message) > 0


@pytest.mark.asyncio
async def test_agent_advisory_guardrail_no_write_tools(add_agent_to_path):
    """Integration: Agent system prompt confirms read-only advisory role."""
    from agent import get_system_prompt

    prompt = get_system_prompt()
    assert "read-only" in prompt.lower() or "never create" in prompt.lower() or "NEVER create" in prompt
    assert "S/4HANA" in prompt


@pytest.mark.asyncio
async def test_agent_handles_empty_tool_list_gracefully(add_agent_to_path):
    """Integration: Agent handles the case where no tools are available."""
    from agent import SampleAgent

    mock_message = MagicMock()
    mock_message.content = "Tools are temporarily unavailable. Please try again later."
    mock_graph_result = {"messages": [mock_message]}

    with patch("mcp_providers.agw.get_mcp_tools", AsyncMock(return_value=[])):
        with patch("langchain_litellm.ChatLiteLLM") as mock_llm_class:
            mock_llm = MagicMock()
            mock_llm_class.return_value = mock_llm

            with patch("langchain.agents.create_agent") as mock_create_agent:
                mock_graph = AsyncMock()
                mock_graph.ainvoke = AsyncMock(return_value=mock_graph_result)
                mock_create_agent.return_value = mock_graph

                agent = SampleAgent()
                response = await agent.invoke(
                    query="What billing items are pending?",
                    context_id="test-context-002",
                    tools=[],
                )

    assert response.status == "completed"


@pytest.mark.asyncio
async def test_milestone_m1_logging(add_agent_to_path):
    """Integration: M1 milestone logging functions emit correct structured logs."""
    from agent import _log_milestone
    import logging

    with patch.object(logging.getLogger("agent"), "info") as mock_log:
        _log_milestone("M1", True, "Billing-due list retrieved — 42 items for period 2026/11")
        mock_log.assert_called_once()
        call_args = mock_log.call_args
        assert "M1" in str(call_args)
        assert "achieved" in str(call_args)


@pytest.mark.asyncio
async def test_milestone_m5_missed_logging(add_agent_to_path):
    """Integration: M5 missed milestone emits correct structured log."""
    from agent import _log_milestone
    import logging

    with patch.object(logging.getLogger("agent"), "info") as mock_log:
        _log_milestone("M5", False, "Period-end reconciliation incomplete — 3 unprocessed items. Status: Not Ready for Close")
        mock_log.assert_called_once()
        call_args = mock_log.call_args
        assert "M5" in str(call_args)
        assert "missed" in str(call_args)
