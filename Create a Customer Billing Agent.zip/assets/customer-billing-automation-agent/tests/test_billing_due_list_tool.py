"""Unit tests for billing-due list monitoring (R1, R6)."""
import json
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "app"))


MOCK_BILLING_LIST = {
    "d": {
        "results": [
            {
                "BillingDocument": "9000000101",
                "BillingDocumentType": "F2",
                "BillingDocumentDate": "/Date(1763049600000)/",
                "BillingBlock": "",
                "CompanyCode": "1000",
                "SoldToParty": "CUST-10001",
                "NetAmount": "12500.00",
                "TransactionCurrency": "EUR",
            },
            {
                "BillingDocument": "9000000102",
                "BillingDocumentType": "F2",
                "BillingDocumentDate": "/Date(1763049600000)/",
                "BillingBlock": "01",
                "CompanyCode": "1000",
                "SoldToParty": "CUST-10002",
                "NetAmount": "8750.00",
                "TransactionCurrency": "EUR",
            },
        ]
    }
}


def _make_mock_tool(name: str, response: dict):
    tool = MagicMock()
    tool.name = name
    tool.ainvoke = AsyncMock(return_value=json.dumps(response))
    return tool


@pytest.mark.asyncio
async def test_billing_due_list_returns_results(add_agent_to_path):
    """M1: Agent can query billing-due list and get pending items."""
    from agent import SampleAgent

    mock_tools = [_make_mock_tool("lis", MOCK_BILLING_LIST)]

    with patch("mcp_providers.agw.get_mcp_tools", AsyncMock(return_value=mock_tools)):
        with patch("langchain_litellm.ChatLiteLLM") as mock_llm_class:
            mock_llm = MagicMock()
            mock_llm_class.return_value = mock_llm

            agent = SampleAgent()
            assert agent is not None


@pytest.mark.asyncio
async def test_billing_due_list_groups_by_document_type(add_agent_to_path):
    """R1: Billing items should be groupable by document type."""
    results = MOCK_BILLING_LIST["d"]["results"]
    invoice_items = [r for r in results if r["BillingDocumentType"] == "F2"]
    blocked_items = [r for r in results if r["BillingBlock"] != ""]

    assert len(invoice_items) == 2
    assert len(blocked_items) == 1
    assert blocked_items[0]["BillingDocument"] == "9000000102"


@pytest.mark.asyncio
async def test_period_risk_detection_flags_blocked_items(add_agent_to_path):
    """R6: Items with billing blocks should be flagged as at-risk."""
    results = MOCK_BILLING_LIST["d"]["results"]
    at_risk = [r for r in results if r["BillingBlock"] not in ("", None)]

    assert len(at_risk) == 1
    assert at_risk[0]["BillingBlock"] == "01"


def test_billing_due_list_count_format(add_agent_to_path):
    """R1: Billing list results should have expected structure."""
    results = MOCK_BILLING_LIST["d"]["results"]
    assert len(results) == 2
    for item in results:
        assert "BillingDocument" in item
        assert "BillingDocumentType" in item
        assert "NetAmount" in item
        assert "CompanyCode" in item


def test_billing_document_types_present(add_agent_to_path):
    """R1: Document types (invoice, credit memo, debit memo) can be identified."""
    doc_types = {"F2": "Invoice", "G2": "Credit Memo", "L2": "Debit Memo"}
    results = MOCK_BILLING_LIST["d"]["results"]
    found_types = {r["BillingDocumentType"] for r in results}
    assert "F2" in found_types
