"""Unit tests for individual billing document status query (R5)."""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "app"))

MOCK_BILLING_DOC = {
    "BillingDocument": "9000000101",
    "BillingDocumentItem": "000010",
    "BillingDocumentType": "F2",
    "BillingDocumentDate": "/Date(1763049600000)/",
    "BillingBlock": "",
    "CompanyCode": "1000",
    "SoldToParty": "CUST-10001",
    "NetAmount": "12500.00",
    "TransactionCurrency": "EUR",
}

MOCK_BLOCKED_DOC = {
    "BillingDocument": "9000000102",
    "BillingDocumentItem": "000010",
    "BillingDocumentType": "F2",
    "BillingDocumentDate": "/Date(1763049600000)/",
    "BillingBlock": "01",
    "CompanyCode": "1000",
    "SoldToParty": "CUST-10002",
    "NetAmount": "8750.00",
    "TransactionCurrency": "EUR",
}

MOCK_ACCTG_DOC = {
    "AccountingDocument": "1400000101",
    "CompanyCode": "1000",
    "FiscalYear": "2026",
    "ReferenceSDDocument": "9000000101",
}

MOCK_JOURNAL_ITEMS = [
    {
        "AccountingDocument": "1400000101",
        "AccountingDocumentItem": "001",
        "GLAccount": "400000",
        "DebitCreditCode": "S",
        "AmountInCompanyCodeCurrency": "12500.00",
        "CompanyCodeCurrency": "EUR",
    }
]


def test_billing_document_detail_returns_all_fields(add_agent_to_path):
    """R5: Single document query returns type, status, block, FI posting, journal entries."""
    doc = MOCK_BILLING_DOC
    acctg = MOCK_ACCTG_DOC
    je = MOCK_JOURNAL_ITEMS

    detail = {
        "billing_document": doc["BillingDocument"],
        "document_type": doc["BillingDocumentType"],
        "billing_block": doc["BillingBlock"],
        "fi_posting_status": "posted" if acctg else "unposted",
        "accounting_document": acctg["AccountingDocument"] if acctg else None,
        "journal_entries": je,
    }

    assert detail["billing_document"] == "9000000101"
    assert detail["document_type"] == "F2"
    assert detail["billing_block"] == ""
    assert detail["fi_posting_status"] == "posted"
    assert detail["accounting_document"] == "1400000101"
    assert len(detail["journal_entries"]) == 1


def test_blocked_document_detail_shows_block_reason(add_agent_to_path):
    """R5: Blocked document detail surfaces the block reason code."""
    doc = MOCK_BLOCKED_DOC
    block_reason_map = {"01": "Pricing Incomplete", "02": "Credit Limit Exceeded"}

    detail = {
        "billing_document": doc["BillingDocument"],
        "billing_block": doc["BillingBlock"],
        "block_reason": block_reason_map.get(doc["BillingBlock"], "Unknown"),
    }

    assert detail["billing_block"] == "01"
    assert detail["block_reason"] == "Pricing Incomplete"


def test_document_detail_unposted_when_no_accounting_doc(add_agent_to_path):
    """R5: Document detail shows unposted when no accounting document found."""
    acctg = None
    fi_status = "posted" if acctg else "unposted"
    assert fi_status == "unposted"


def test_document_detail_gl_entries_linked_correctly(add_agent_to_path):
    """R5: Journal entries are linked to the correct accounting document."""
    for entry in MOCK_JOURNAL_ITEMS:
        assert entry["AccountingDocument"] == MOCK_ACCTG_DOC["AccountingDocument"]
        assert entry["GLAccount"] == "400000"


def test_document_detail_net_amount_in_response(add_agent_to_path):
    """R5: Net amount and currency are present in document detail."""
    doc = MOCK_BILLING_DOC
    assert "NetAmount" in doc
    assert "TransactionCurrency" in doc
    assert float(doc["NetAmount"]) > 0
