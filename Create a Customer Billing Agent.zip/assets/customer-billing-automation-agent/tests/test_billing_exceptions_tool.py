"""Unit tests for billing exception detection and resolution (R2)."""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "app"))

BLOCK_REASON_MAP = {
    "01": "Pricing Incomplete",
    "02": "Credit Limit Exceeded",
    "03": "Delivery Not Goods-Issued",
    "04": "Incomplete Data",
    "05": "Account Assignment Incomplete",
    "06": "Customer Master Incomplete",
}

MOCK_EXCEPTIONS = [
    {
        "BillingDocument": "9000000102",
        "BillingDocumentType": "F2",
        "BillingBlock": "01",
        "CompanyCode": "1000",
        "SoldToParty": "CUST-10002",
        "NetAmount": "8750.00",
    },
    {
        "BillingDocument": "9000000105",
        "BillingDocumentType": "F2",
        "BillingBlock": "03",
        "CompanyCode": "1000",
        "SoldToParty": "CUST-10005",
        "NetAmount": "3200.00",
    },
]


def test_exception_categorization_by_block_code(add_agent_to_path):
    """R2: Exceptions are categorized correctly by billing block reason code."""
    categorized = []
    for doc in MOCK_EXCEPTIONS:
        block_code = doc["BillingBlock"]
        categorized.append({
            "document": doc["BillingDocument"],
            "block_code": block_code,
            "category": BLOCK_REASON_MAP.get(block_code, "Unknown"),
        })

    assert len(categorized) == 2
    assert categorized[0]["category"] == "Pricing Incomplete"
    assert categorized[1]["category"] == "Delivery Not Goods-Issued"


def test_exception_list_excludes_unblocked_items(add_agent_to_path):
    """R2: Only documents with non-empty billing blocks are exceptions."""
    all_docs = [
        {"BillingDocument": "9000000101", "BillingBlock": ""},
        {"BillingDocument": "9000000102", "BillingBlock": "01"},
        {"BillingDocument": "9000000103", "BillingBlock": None},
        {"BillingDocument": "9000000105", "BillingBlock": "03"},
    ]
    exceptions = [d for d in all_docs if d["BillingBlock"] not in ("", None)]

    assert len(exceptions) == 2
    assert all(d["BillingBlock"] not in ("", None) for d in exceptions)


def test_exception_resolution_steps_available_for_known_codes(add_agent_to_path):
    """R2: Resolution steps are available for all known block reason codes."""
    known_codes = list(BLOCK_REASON_MAP.keys())
    assert "01" in known_codes  # Pricing Incomplete
    assert "02" in known_codes  # Credit Limit
    assert "03" in known_codes  # Delivery not GI'd
    assert "04" in known_codes  # Incomplete Data
    assert len(known_codes) >= 4


def test_exception_response_structure(add_agent_to_path):
    """R2: Exception response has required fields for Finance Controller."""
    for exc in MOCK_EXCEPTIONS:
        assert "BillingDocument" in exc
        assert "BillingBlock" in exc
        assert "BillingDocumentType" in exc
        assert exc["BillingBlock"] != ""


def test_pricing_discrepancy_identified_as_block_01(add_agent_to_path):
    """R2: Pricing discrepancy maps to block code 01."""
    pricing_exceptions = [
        d for d in MOCK_EXCEPTIONS if d["BillingBlock"] == "01"
    ]
    assert len(pricing_exceptions) == 1
    assert pricing_exceptions[0]["BillingDocument"] == "9000000102"
