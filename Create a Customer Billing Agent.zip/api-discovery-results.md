# API Discovery Results

## Customer Billing Automation Agent

| API Name | Type | ORD ID | Files | Status |
|----------|------|--------|-------|--------|
| Billing Document - Read Subsequent Billing Documents | OData | `sap.s4:apiResource:API_SUBSQNT_BILLG_DOC_SBI_SRV:v1` | EDMX, OpenAPI JSON | Available |
| Accounting Document - Read | OData | `sap.s4:apiResource:API_OPLACCTGDOCITEMCUBE_SRV:v1` | EDMX, OpenAPI JSON | Available |
| Journal Entry Item - Read | OData | `sap.s4:apiResource:API_JOURNALENTRYITEMBASIC_SRV:v1` | EDMX, OpenAPI JSON | Available |

All three APIs are OData with EDMX files available. EDMX preferred for MCP translation.
