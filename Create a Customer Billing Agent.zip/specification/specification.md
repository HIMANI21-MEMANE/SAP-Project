# Specification

> **Guidelines**: Read [guidelines.md](./guidelines.md) before executing ANY tasks below.

Check off items as completed.

## Solution Setup

- [x] Create asset directory: `mkdir -p assets/customer-billing-automation-agent/`
- [x] Invoke `setup-solution` skill to create `solution.yaml` and `asset.yaml` files for the agent asset
- [x] Validate `asset.yaml` and `solution.yaml` exist and are well-formed

## Asset Implementation

- [x] Execute specification/customer-billing-automation-agent/specification.md (all items)
