# Specification: customer-billing-automation-agent

> **Guidelines**: Read all applicable guidelines before executing ANY tasks below:
> - [guidelines.md](../guidelines.md) — Universal execution rules
> - [guidelines-agent.md](../guidelines-agent.md) — Universal agent patterns
> - [guidelines-agent-python.md](../guidelines-agent-python.md) — Python implementation details
> - [guidelines-agent-skills.md](../guidelines-agent-skills.md) — Runtime skills patterns
> - [guidelines-agent-mcp.md](../guidelines-agent-mcp.md) — MCP integration patterns

---

## Basic Setup

- [x] Read `product-requirements-document.md` and `intent.md` for full context on the billing agent requirements
- [x] Bootstrap agent code in `assets/customer-billing-automation-agent/` using instructions from the sap-agent-bootstrap section (invoke from inside `assets/customer-billing-automation-agent/`, use copy commands — do NOT create files manually)
- [x] Install dependencies, validate the agent starts and responds at `/.well-known/agent.json`

---

## Runtime Skills

- [x] Create a runtime skill `assets/customer-billing-automation-agent/app/skills/billing-exception-resolution/SKILL.md` with:
  - YAML frontmatter: `name: billing-exception-resolution`, `description: Step-by-step guidance for resolving billing blocks, pricing discrepancies, and data mismatches`
  - Body: Decision tree for common billing block reason codes (pricing incomplete, delivery not goods-issued, credit limit exceeded, etc.) with S/4HANA transaction navigation steps for each resolution path
- [x] Create a runtime skill `assets/customer-billing-automation-agent/app/skills/period-end-readiness/SKILL.md` with:
  - YAML frontmatter: `name: period-end-readiness`, `description: Rules and checklist for confirming billing completeness before period-end financial close`
  - Body: Readiness criteria checklist — zero unprocessed billing items, all FI postings confirmed, no open billing blocks, GL entries verified — with pass/fail logic and escalation guidance

---

## Project-Specific Tasks

### R1 — Billing-Due List Monitoring

- [ ] Implement a `billing_due_list_tool` in `assets/customer-billing-automation-agent/app/` that:
  - Calls the `API_SUBSQNT_BILLG_DOC_SBI_SRV` MCP tool to query pending billing documents
  - Filters by billing status (pending/blocked) and the current fiscal period
  - Groups results by document type (invoice, credit memo, debit memo) with counts and earliest open date
  - Returns a structured summary list
- [ ] Add system prompt instruction: "When asked about the billing-due list or pending billing items, always use the billing-due-list tool to retrieve live data from S/4HANA. Never estimate or fabricate billing document counts or dates."
- [ ] Implement period-risk detection: if period-end date is within a configurable threshold (default 3 days), flag documents past their expected billing date as at-risk

### R2 — Exception Detection & Guided Resolution

- [ ] Implement a `billing_exceptions_tool` in `assets/customer-billing-automation-agent/app/` that:
  - Calls the `API_SUBSQNT_BILLG_DOC_SBI_SRV` MCP tool to retrieve billing documents with non-empty billing block reasons
  - Categorizes exceptions: billing block, pricing discrepancy, data mismatch, incomplete data
  - Returns exception list with document number, type, block reason code, and description
- [ ] Wire the `billing-exception-resolution` runtime skill so the agent loads it when exception resolution guidance is requested
- [ ] Add system prompt instruction: "When surfacing billing exceptions, always load the billing-exception-resolution skill to provide accurate, step-by-step resolution guidance referencing the correct S/4HANA transactions."

### R3 — FI Posting Validation

- [ ] Implement a `fi_posting_validation_tool` in `assets/customer-billing-automation-agent/app/` that:
  - Accepts a billing document number or a list of billing document numbers
  - Calls the `API_OPLACCTGDOCITEMCUBE_SRV` MCP tool to check for corresponding accounting document entries (AR line items)
  - Calls the `API_JOURNALENTRYITEMBASIC_SRV` MCP tool to verify GL journal entries exist for the billing documents
  - Returns per-document posting status: posted (AR + GL confirmed), partially posted, or unposted (FI exception)
- [ ] Add system prompt instruction: "When validating FI postings, always check both accounting documents and journal entries. If no accounting document is found for a billing document, flag it explicitly as an FI posting exception — do not assume it will post later."

### R4 — Period-End Readiness Report

- [ ] Implement a `period_end_readiness_tool` in `assets/customer-billing-automation-agent/app/` that:
  - Queries all billing documents for the specified fiscal period using `API_SUBSQNT_BILLG_DOC_SBI_SRV`
  - Validates FI postings for all released documents using `API_OPLACCTGDOCITEMCUBE_SRV` and `API_JOURNALENTRYITEMBASIC_SRV`
  - Computes: total billing items, items processed, items pending, items with FI posting gaps
  - Determines overall readiness status: "Ready for Close" (zero pending + all FI posted) or "Not Ready for Close" (with reason summary)
  - Returns a structured readiness report
- [ ] Wire the `period-end-readiness` runtime skill so the agent loads it when generating the readiness report
- [ ] Add system prompt instruction: "When generating a period-end readiness report, always load the period-end-readiness skill to apply the correct completeness criteria. The report must be sourced entirely from live S/4HANA data — never estimated."

### R5 — Individual Document Status Query

- [ ] Implement a `billing_document_detail_tool` in `assets/customer-billing-automation-agent/app/` that:
  - Accepts a single billing document number
  - Retrieves document type, status, billing block reason (if any) from `API_SUBSQNT_BILLG_DOC_SBI_SRV`
  - Retrieves FI posting status from `API_OPLACCTGDOCITEMCUBE_SRV`
  - Retrieves associated GL journal entries from `API_JOURNALENTRYITEMBASIC_SRV`
  - Returns a complete, single-document status summary
- [ ] Add system prompt instruction: "When a user asks about a specific billing document by number, use the billing-document-detail tool to retrieve the full picture in one response — document type, status, block reason, FI posting, and journal entries."

### R6 — Period-End Close Risk Alert

- [ ] Implement period-close risk detection logic in the `billing_due_list_tool`:
  - Accept an optional `period_end_date` parameter
  - If period_end_date is within the configured threshold (default 3 business days), and unprocessed items exist, the tool response includes a risk alert payload with: alert flag, days-to-close, count and types of at-risk items
- [ ] Add system prompt instruction: "Proactively alert the Finance Controller when unprocessed billing items risk delaying the period-end close. Surface the alert clearly with item counts and types — do not bury it in the response."

### System Prompt & Agent Persona

- [ ] Configure the agent's system prompt in `assets/customer-billing-automation-agent/app/agent.py` to include:
  - Agent identity: "You are the Customer Billing Automation Agent, an AI assistant for Finance Controllers and AR Specialists managing the SAP S/4HANA billing process."
  - Advisory guardrail: "You are a read-only advisor. You NEVER create, modify, cancel, or post billing documents. All write actions must be executed by the user directly in SAP S/4HANA."
  - Data integrity rule: "Always retrieve live data from S/4HANA via the available tools. Never estimate, fabricate, or assume billing data."
  - Source citation rule: "Always cite the billing document number or accounting document number that is the source of any status you report."
  - Period-end focus: "Every response should help the Finance Controller move toward full billing completeness before period-end close."

### Extensibility Hooks

- [ ] Add a clearly commented extension point in `agent.py` under a `# EXTENSION POINT: Write-Back Tools` comment block:
  - Comment documenting which API would be used: `OP_API_BILLING_DOCUMENT_SRV_0001` for billing document create/cancel
  - Placeholder tool registration call (commented out) for `billing_document_create_tool` and `billing_document_cancel_tool`
- [ ] Add a clearly commented extension point for AFC integration under `# EXTENSION POINT: AFC Integration`:
  - Comment documenting SAP Advanced Financial Closing API integration for automated period-end triggering

---

## MCP API Scope

```
MCP API: sap.s4:apiResource:API_SUBSQNT_BILLG_DOC_SBI_SRV:v1
MCP tool scope: read-only
Resources in scope: SubsqntBillgDocItem, SubsqntBillgDoc

MCP API: sap.s4:apiResource:API_OPLACCTGDOCITEMCUBE_SRV:v1
MCP tool scope: read-only
Resources in scope: A_OperationalAcctgDocItemCube

MCP API: sap.s4:apiResource:API_JOURNALENTRYITEMBASIC_SRV:v1
MCP tool scope: read-only
Resources in scope: A_JournalEntryItemBasic
```

---

## Business Instrumentation

- [x] Implement structured logging and OpenTelemetry spans for all five milestones from the PRD:
  - **M1 — Billing-Due List Monitoring**
    - `M1.achieved: Billing-due list retrieved — {count} pending items identified for period {period}`
    - `M1.missed: Billing-due list query did not return results — API unavailable or no items found for period {period}`
  - **M2 — Document Generation (Advisory)**
    - `M2.achieved: Billing documents confirmed generated — {count} invoices, {count} credit memos, {count} debit memos for period {period}`
    - `M2.missed: Document generation check incomplete — missing document types or API returned no data for period {period}`
  - **M3 — Error Detection & Resolution**
    - `M3.achieved: Exception detection complete — {count} billing blocks and {count} pricing discrepancies surfaced for period {period}`
    - `M3.missed: Exception detection incomplete — unable to retrieve block reasons for period {period}`
  - **M4 — FI Integration Confirmed**
    - `M4.achieved: FI posting validation complete — {count} billing documents confirmed posted to FI-AR and GL for period {period}`
    - `M4.missed: FI posting validation incomplete — {count} billing documents have no corresponding accounting document for period {period}`
  - **M5 — Period-End Reconciliation**
    - `M5.achieved: Period-end billing reconciliation complete — all billing items processed and FI postings confirmed for period {period}. Status: Ready for Close`
    - `M5.missed: Period-end reconciliation incomplete — {count} unprocessed items or FI posting gaps remain for period {period}. Status: Not Ready for Close`
- [x] Extract business logic from `stream()` into plain async helpers to avoid `GeneratorExit` context errors with OpenTelemetry spans
- [x] Verify `bootstrap(app)` is called after `app = server.build()` in `main.py`

---

## MCP Tool Integration

- [ ] Verify `api-discovery-results.md` exists at workspace root with ORD IDs for all three required APIs
- [ ] Invoke `mcp-translation-file` skill with the three downloaded EDMX specs in `specification/customer-billing-automation-agent/api-specs/`:
  - `API_SUBSQNT_BILLG_DOC_SBI_SRV.edmx` → ORD ID: `sap.s4:apiResource:API_SUBSQNT_BILLG_DOC_SBI_SRV:v1`
  - `API_OPLACCTGDOCITEMCUBE_SRV.edmx` → ORD ID: `sap.s4:apiResource:API_OPLACCTGDOCITEMCUBE_SRV:v1`
  - `API_JOURNALENTRYITEMBASIC_SRV.edmx` → ORD ID: `sap.s4:apiResource:API_JOURNALENTRYITEMBASIC_SRV:v1`
- [ ] Invoke `setup-solution` skill to create `solution.yaml` and `asset.yaml` for the agent and register the three generated MCP server assets
- [ ] Wire MCP tool loading in `agent.py` using `get_mcp_tools()` from the `mcp_tools` module (never import directly from `sap_cloud_sdk.agentgateway`)
- [ ] Add MCP server dependencies to `asset.yaml` under `requires` — one entry per MCP server using exact ORD IDs from generated assets
- [ ] Generate `mcp-mock.json` using the `mcp-mock-config` skill after MCP translation files are complete

---

## Testing

- [x] `conftest.py` only sets `IBD_TESTING=true`
- [x] Write unit tests in `assets/customer-billing-automation-agent/tests/` — one per tool:
  - `test_billing_due_list_tool.py` — tests pending item retrieval, period filtering, at-risk flagging
  - `test_billing_exceptions_tool.py` — tests exception categorization, block reason parsing
  - `test_fi_posting_validation_tool.py` — tests AR posting check, GL journal entry check, unposted detection
  - `test_period_end_readiness_tool.py` — tests readiness calculation, Ready/Not-Ready status, report structure
  - `test_billing_document_detail_tool.py` — tests full single-document detail retrieval combining all three APIs
- [x] Write one integration test in `assets/customer-billing-automation-agent/tests/test_integration.py` exercising the end-to-end agent flow: Finance Controller asks for period-end readiness report → agent invokes tools → returns structured readiness response (mocked LLM + mocked MCP tools)
- [x] Run `pytest` from `assets/customer-billing-automation-agent/` (no args) — if coverage < 70%, add tests until threshold met
- [x] Run `pytest` again from `assets/customer-billing-automation-agent/` (no args) to generate final `test_report.json`
- [x] Verify `test_report.json` exists in `assets/customer-billing-automation-agent/`
